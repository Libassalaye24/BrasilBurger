<div class="als-inserter">	
	<div class="widefat">
		<h3><?php esc_html_e( 'Field list', 'auto-listings' ) ?></h3>
		<div class="als-fields" id="als-fields">
			<!-- render button fields here -->
		</div>
		<hr>
		<div class="als-fields" id="als-fields-extra">
			<!-- render extra fields here -->
		</div>
	</div>
</div>