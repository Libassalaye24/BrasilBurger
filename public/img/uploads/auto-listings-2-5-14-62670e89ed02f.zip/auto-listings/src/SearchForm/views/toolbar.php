<ul class="als-tab__nav">
	<li class="als-tab__link is-active" data-tab="template-editor"><?php esc_html_e( 'Template', 'auto-listings' ) ?></li>
	<li class="als-tab__link" data-tab="css-editor"><?php esc_html_e( 'CSS', 'auto-listings' ) ?></li>
	<li class="als-tab__link" data-tab="js-editor"><?php esc_html_e( 'JavaScript', 'auto-listings' ) ?></li>
</ul>
