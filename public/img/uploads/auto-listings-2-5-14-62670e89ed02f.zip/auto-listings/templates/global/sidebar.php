<?php
/**
 * Sidebar
 *
 * This template can be overridden by copying it to yourtheme/listings/global/sidebar.php.
 *
 * @package Auto Listings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_sidebar( 'listings' );
